import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class lineas_0_1_1 extends PApplet {

public void setup(){

rectMode(CENTER);
 background(0);
 noFill();
 noCursor();
}

public void draw(){
  stroke(255);
 if(mouseX<width/2) stroke(255,0,0);
 else stroke(0,0,255);
 if(mouseX<=mouseY) line(0,0,mouseX, mouseY);
 else line(mouseX, mouseY,width, height);
 if(mouseX!=300) line(width,height,mouseX,mouseY);
 else line(0,height,mouseX,mouseY);
 if(mouseX<mouseY) line(width,0,mouseX,mouseY);
 else line(0,height,mouseX,mouseY);
}

public void keyPressed(){
   if(key == 'r') background(0);
   if(key == 's') saveFrame();
   if(key == 'q') exit();
}
  public void settings() { 
size(displayWidth, displayHeight); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "lineas_0_1_1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
